// Acepta el Reto 416: Michael J. Fox y el Pato Donald

import java.util.*;

public class PatoDonald
{	
    public static void main(String[] args) 
    {
		Scanner sc = new Scanner(System.in);
		Set<String> cumples;
        int numFechas;
        String[] fechas;
			
		do
		{
			numFechas = sc.nextInt();
			
			if (numFechas > 0)
			{
				cumples = new HashSet<>();
				sc.nextLine();
				
				fechas = sc.nextLine().split(" ");
				for (String fecha: fechas)
				{
                    // Nos quedamos con el día y mes
					cumples.add(fecha.substring(0, fecha.lastIndexOf("/")));
				}
				
				System.out.println(cumples.size() != fechas.length? "SI" : "NO");
			}
			
		} while(numFechas > 0);
    }    
}
