// Acepta el Reto 765: Ninots indultados

import java.util.*;

public class NinotsIndultados
{
    public static void main(String[] args)
    {
        Scanner sc = new Scanner(System.in);
        HashMap<String, Integer> votosAdulto, votosInfantil;
        int votos, maxVotosAdulto, maxVotosInfantil;
        boolean empateAdulto, empateInfantil;
        String nombre, nombreAdulto, nombreInfantil;
        
        do
        {
            votos = sc.nextInt();
            if(votos != 0)
            {
                votosAdulto = new HashMap<>();
                votosInfantil = new HashMap<>();
                maxVotosAdulto = maxVotosInfantil = 0;
                empateAdulto = empateInfantil = true;
                nombreAdulto = nombreInfantil = "";

                for(int i = 1; i <= votos; i++)
                {
                    nombre = sc.next();
                    if(nombre.trim().charAt(0) < 'a')
                    {
                        if(votosAdulto.containsKey(nombre))
                        {
                            votosAdulto.put(nombre, votosAdulto.get(nombre) + 1);
                        }
                        else
                        {
                            votosAdulto.put(nombre, 1);
                        }
                    }
                    else
                    {
                        if(votosInfantil.containsKey(nombre))
                        {
                            votosInfantil.put(nombre, votosInfantil.get(nombre) + 1);
                        }
                        else
                        {
                            votosInfantil.put(nombre, 1);
                        }
                    }
                }
                
                // Votos infantiles
                for(String n : votosInfantil.keySet())
                {
                    if(votosInfantil.get(n) > maxVotosInfantil)
                    {
                        empateInfantil = false;
                        maxVotosInfantil = votosInfantil.get(n);
                        nombreInfantil = n;
                    }
                    else if(votosInfantil.get(n) == maxVotosInfantil)
                    {
                        empateInfantil = true;
                    }
                }

                // Votos adultos
                for(String n : votosAdulto.keySet())
                {
                    if(votosAdulto.get(n) > maxVotosAdulto)
                    {
                        empateAdulto = false;
                        maxVotosAdulto = votosAdulto.get(n);
                        nombreAdulto = n;
                    }
                    else if(votosAdulto.get(n) == maxVotosAdulto)
                    {
                        empateAdulto = true;
                    }
                }
                
                System.out.print(empateInfantil?"empate":nombreInfantil);
                System.out.print(" ");
                System.out.println(empateAdulto?"EMPATE":nombreAdulto);                
            }
        }
        while(votos != 0);
    }
}
