// Acepta el Reto 521: ¿Podemos empezar?

import java.util.*;

public class PodemosEmpezar
{
    public static void main(String[] args)
    {
        Scanner sc = new Scanner(System.in);
        HashSet<String> viviendas;
        int pisos, letras, asistentes, totalViviendas, mitad;

        do
        {
            pisos = sc.nextInt();
            letras = sc.nextInt();
            asistentes = sc.nextInt();

            if (pisos != 0)
            {
                // Calculamos el total de viviendas
                totalViviendas = pisos * letras;

                viviendas = new HashSet<>();
                // Añadimos en el conjunto el número de piso seguido de la letra
                for (int i = 0; i < asistentes; i ++)
                {
                    String piso = sc.next();
                    String letra = sc.next();
                    viviendas.add(piso + letra);
                }

                // Calculamos la mitad de asistentes necesaria
                if (totalViviendas % 2 == 0)
                    mitad = totalViviendas / 2;
                else
                    mitad = totalViviendas / 2 + 1;

                if (viviendas.size() >= mitad)
                    System.out.println("EMPEZAMOS");
                else
                    System.out.println("ESPERAMOS");
            }
            
        } while (pisos != 0);
    }
}
