import java.util.*;

public class TelegramaCorto
{
    static HashMap<Character, String> crearMapaMorse()
    {
        HashMap<Character, String> tabla = new HashMap<>();
        
        tabla.put('A', ".-");
        tabla.put('B', "-...");
        tabla.put('C', "-.-.");
        tabla.put('D', "-..");
        tabla.put('E', ".");
        tabla.put('F', "..-.");
        tabla.put('G', "--.");
        tabla.put('H', "....");
        tabla.put('I', "..");
        tabla.put('J', ".---");
        tabla.put('K', "-.-");
        tabla.put('L', ".-..");
        tabla.put('M', "--");
        tabla.put('N', "-.");
        tabla.put('O', "---");
        tabla.put('P', ".--.");
        tabla.put('Q', "--.-");
        tabla.put('R', ".-.");
        tabla.put('S', "...");
        tabla.put('T', "-");
        tabla.put('U', "..-");
        tabla.put('V', "...-");
        tabla.put('W', ".--");
        tabla.put('X', "-..-");
        tabla.put('Y', "-.--");
        tabla.put('Z', "--..");
        tabla.put('!', "-.-.--");
        tabla.put('?', "..--..");
        
        return tabla;
    }
    
    public static void main(String[] args)
    {
        HashMap<Character, String> tabla = crearMapaMorse();
        String linea;        
        Scanner sc = new Scanner(System.in);
        int casos = sc.nextInt();
        sc.nextLine();
        
        for(int n = 0; n < casos; n++)
        {
            linea = sc.nextLine();
            int total = 0;
            for(int i = 0; i < linea.length(); i++)
            {
                if(linea.charAt(i) != ' ')
                {
                    String representacion = tabla.get(linea.charAt(i));
                    for(int j = 0; j < representacion.length(); j++)
                    {
                        if(representacion.charAt(j) == '.')
                            total += 1;
                        else
                            total += 3;
                    }
                    // Un punto entre cada símbolo
                    total += representacion.length() - 1;
                    
                    if (i > 0 && linea.charAt(i-1) != ' ')
                    {
                        // 3 puntos entre cada letra
                        total += 3;
                    }
                }                
                else
                {
                    // 5 puntos entre cada palabra
                    total += 5;
                }
            }            
            
            System.out.println(total);
        }
    }
}
