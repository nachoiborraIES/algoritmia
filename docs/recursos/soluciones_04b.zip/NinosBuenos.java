// Acepta el Reto 366: Los niños buenos

import java.util.*;

class Nino implements Comparable<Nino>
{
    private int bueno;
    private int peso;
    
    public Nino(int bueno, int peso)
    {
        this.bueno = bueno;
        this.peso = peso;
    }
          
    @Override
    public int compareTo(Nino n)
    {
        // Comparamos "bueno" de mayor a menor
        int resultado = Integer.compare(n.bueno, this.bueno);
        // Si coincide, comparamos "peso" de menor a mayor
        if(resultado == 0)
        {
            resultado = Integer.compare(this.peso, n.peso);
        }
        return resultado;
    }

    @Override
    public String toString()
    {
        return bueno + " " + peso;
    }
}

public class NinosBuenos
{
    public static void main(String[] args)
    {
        Scanner sc = new Scanner(System.in);
        ArrayList<Nino> lista;
        int n;
        
        do
        {
            // Leemos el número de niños
            n = sc.nextInt();
            if(n != 0)
            {
                // Almacenamos los niños en una lista
                lista = new ArrayList<Nino>();
                for(int i = 1; i <= n; i++)
                {
                    lista.add(new Nino(sc.nextInt(), sc.nextInt()));
                }
                // Ordenamos por el criterio de la clase Nino
                Collections.sort(lista);
                for(Nino nino : lista)
                {
                    System.out.println(nino);
                }
                // Debemos sacar una línea en blanco al final de cada caso
                System.out.println();
            }
        }
        while(n != 0);
    }
}
