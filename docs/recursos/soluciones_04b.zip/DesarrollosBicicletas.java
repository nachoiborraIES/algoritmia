// Acepta el Reto 268: Desarrollos en las bicicletas

import java.util.*;

class Desarrollo implements Comparable<Desarrollo>
{
    int plato;
    int corona;

    public Desarrollo(int plato, int corona)
    {
        this.plato = plato;
        this.corona = corona;
    }

    public float calcular()
    {
        return (float)plato / corona;
    }

    @Override
    public int compareTo(Desarrollo d)
    {
        return Float.compare(this.calcular(), d.calcular());
    }
    
    @Override
    public String toString()
    {
        return plato + "-" + corona;
    }
}

public class DesarrollosBicicletas
{
    public static void main(String[] args)
    {
        Scanner sc = new Scanner(System.in);
        ArrayList<Desarrollo> desarrollos;
        int[] medidasPlatos, medidasCoronas;
        int platos, coronas;
        
        do
        {
            platos = sc.nextInt();
            coronas = sc.nextInt();
            
            if(platos > 0)
            {
                desarrollos = new ArrayList<>();
                
                // Leemos medidas de los platos y las coronas
                
                medidasPlatos = new int[platos];
                for(int i = 0; i < platos; i++)
                    medidasPlatos[i] = sc.nextInt();
                    
                medidasCoronas = new int[coronas];
                for(int i = 0; i < coronas; i++)
                    medidasCoronas[i] = sc.nextInt();
                
                // Recorremos cada array formando todas las posibles
                // combinaciones, y creamos un objeto con cada una
                for(int i = 0; i < medidasPlatos.length; i++)
                {
                    for(int j = 0; j < medidasCoronas.length; j++)
                    {
                        desarrollos.add(new Desarrollo(medidasPlatos[i],
                            medidasCoronas[j]));
                    }
                }
                
                // Ordenamos los desarrollos
                Collections.sort(desarrollos);
                for(int i = 0; i < desarrollos.size(); i++)
                {
                    if (i != 0)
                        System.out.print(" ");
                    System.out.print(desarrollos.get(i));
                }
                System.out.println();
            }
        }
        while(platos > 0);
    }
}
