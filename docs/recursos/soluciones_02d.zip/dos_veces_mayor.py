# CodeWars: "Twice as old"

def twice_as_old(dad_years_old, son_years_old):
    years = 0
    d = dad_years_old
    s = son_years_old
    
    while d != 2*s and s > 0:
        d -= 1
        s -= 1
        years += 1
    
    if d != 2*s:
        years = 0
        d = dad_years_old
        s = son_years_old
        while d != 2*s:
            d += 1
            s += 1
            years += 1
    
    return years
