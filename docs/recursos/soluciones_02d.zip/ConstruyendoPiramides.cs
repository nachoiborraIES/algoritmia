// Kattis: "Building pyramids"

using System;

class Ejercicio
{
    static void Main()
    {
        int n = Convert.ToInt32(Console.ReadLine());
        int altura = 0;
        int lado = 1;
        while(n > 0)
        {
            n = n - lado*lado;
            if(n >= 0)
            {
                altura++;
                lado = lado + 2;
            }
        }
        
        Console.WriteLine(altura);
    }
}
