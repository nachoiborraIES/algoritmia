// Acepta el Reto 150: A dibujar hexágonos

import java.util.Scanner;

public class Hexagonos
{
    public static void main(String[] args)
    {
        Scanner sc = new Scanner(System.in);
        int lado, filas, simbolos, espacios;
        char simbolo;
        
        do
        {
            lado = sc.nextInt();
            simbolo = sc.nextLine().trim().charAt(0);

            if (lado > 0)
            {
                // Número total de filas a dibujar
                filas = lado * 2 - 1;

                // Comenzamos con tantos símbolos como el lado
                // y un espacio menos
                simbolos = lado;
                espacios = lado - 1;

                for (int i = 1; i <= filas; i++)
                {
                    // Parte superior: incrementamos los símbolos de 2 en 2
                    // y decrementamos espacios de uno en uno
                    if (i > 1 && i <= lado)
                    {
                        simbolos += 2;
                        espacios--;
                    }
                    // Parte inferior: decrementamos símbolos de 2 en 2
                    // e incrementamos espacios de uno en uno
                    else if (i > lado)
                    {
                        simbolos -= 2;
                        espacios++;
                    }

                    // Dibujamos espacios y símbolos para la fila actual
                    for (int j = 0; j < espacios; j++)
                        System.out.print(" ");
                    for (int j = 0; j < simbolos; j++)
                        System.out.print(simbolo);
                    // Pasamos a la siguiente línea para la siguiente iteración
                    System.out.println();
                }
            }       
        } while (lado > 0);
    }
}

