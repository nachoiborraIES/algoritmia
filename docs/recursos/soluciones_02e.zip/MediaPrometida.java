// Acepta el Reto 622: La media prometida

import java.util.Scanner;

public class MediaPrometida
{
    public static void main(String[] args)
    {
        Scanner sc = new Scanner(System.in);
        int examenesHechos, examen, sumaExamenes, mediaPrometida, solucion;
        
        do
        {
            examenesHechos = sc.nextInt();
            if(examenesHechos != 0)
            {
                sumaExamenes = 0;
                for (int i = 1; i <= examenesHechos; i++)
                {
                    examen = sc.nextInt();
                    sumaExamenes += examen;
                }
                mediaPrometida = sc.nextInt();
                // (sumaExamenes + x) / (examenesHechos + 1) = mediaPrometida
                // Despejamos x (solucion):
                solucion = mediaPrometida * (examenesHechos + 1) - sumaExamenes;
                if (solucion >= 0 && solucion <= 10)
                {
                    System.out.println(solucion);
                }
                else
                {
                    System.out.println("IMPOSIBLE");
                }
            }
        }
        while(examenesHechos != 0);
    }
}
