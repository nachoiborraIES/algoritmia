// Acepta el Reto 158: Los saltos de Mario

import java.util.Scanner;

public class SaltosMario
{    
    public static void main(String[] args)
    {
        Scanner sc = new Scanner(System.in);
        int casos = sc.nextInt();
        int muros, arriba, abajo, previo, actual;

        // Procesamos cada caso de prueba
        for(int i = 1; i <= casos; i++)
        {
            // Leemos la cantidad de muros
            muros = sc.nextInt();
            // Aún no hemos hecho ningún salto desde un muro previo
            // en esta tanda
            previo = -1;
            // Contadores de saltos ascendentes y descendentes
            arriba = abajo = 0;
            // Segundo bucle: leemos los muros de este caso
            for(int j = 0; j < muros; j++)
            {
                actual = sc.nextInt();
                // Miramos si venimos de una torre previa
                // y si es un salto arriba o abajo
                if (previo >= 0 && actual > previo)
                    arriba++;
                else if (previo >= 0 && actual < previo)
                    abajo++;
                previo = actual;
            }

            System.out.println(arriba + " " + abajo);
        }  
    }
}
