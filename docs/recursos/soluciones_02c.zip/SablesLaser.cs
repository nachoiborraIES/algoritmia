// Code Wars: "How many lightsabers do you own?"
// Copiar y pegar el siguiente código en el formulario del intento

using System;

public class Kata
{
    public static int HowManyLightsabersDoYouOwn(string name)
    {
        if(name == "Zach")
            return 18;
        else
            return 0;
    }
}
