// Acepta el Reto 369: Contando en la arena

import java.util.Scanner;

public class ContandoArena
{
    public static void main(String[] args)
    {
        Scanner sc = new Scanner(System.in);
        int numero;
        
        do
        {
            numero = sc.nextInt();
            
            if(numero != 0)
            {
                for(int i = 1; i <= numero; i++)
                {
                    System.out.print(1);
                }
                System.out.println();
            }
        }
        while(numero != 0);
    }
}
