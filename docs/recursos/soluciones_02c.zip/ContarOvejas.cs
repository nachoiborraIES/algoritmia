// CodeWars: "If you can't sleep, just count sheep!!"
// Copiar este código en el formulario del intento

using System;

public static class Kata
{
    public static string CountSheep(int n)
    {
        string result = "";
        for (int i = 1; i <= n; i++)
        {
            result = result + i + " sheep...";
        }
        return result;
    }
}
