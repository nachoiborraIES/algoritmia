// Kattis: "Odd echo"

using System;

class Ejemplo
{
    static void Main()
    {
        int numPalabras;
        string palabra;

        // Leemos el número de palabras
        numPalabras = Convert.ToInt32(Console.ReadLine());

        // Recorremos las palabras y mostramos las impares
        for(int i = 1; i <= numPalabras; i++)
        {
            palabra = Console.ReadLine();
            if(i % 2 != 0)
            {
                Console.WriteLine(palabra);
            }
        }
    }
}
