// Acepta el Reto 283: Invirtiendo en Jaén

import java.util.Scanner;

public class InvirtiendoJaen
{
    static int calcularArea(char[][] mapa, int fila, int columna)
    {
        if (fila < 0 || fila >= mapa.length || 
            columna < 0 || columna >= mapa[0].length || 
            mapa[fila][columna] == ' ')
            // Caso base: hemos llegado a una casilla donde no hay más,
            // o nos hemos salido del mapa en esa dirección
            return 0;
        else
        {
            // Marcamos la casilla como vacía para no contarla en otro proceso
            mapa[fila][columna] = ' ';
            // Sumamos 1 al conteo y seguimos buscando en 4 direcciones
            return 1 + calcularArea(mapa, fila-1, columna) 
                + calcularArea(mapa, fila+1, columna)
                + calcularArea(mapa, fila, columna-1)
                + calcularArea(mapa, fila, columna+1);
        }
    }    
    
    public static void main(String[] args)
    {
        Scanner sc = new Scanner(System.in);
        int filas, columnas;
        String linea;

        while (sc.hasNext())
        {
            // Construcción del mapa
            
            filas = sc.nextInt();
            columnas = sc.nextInt();
            // Pasamos a la siguiente línea
            sc.nextLine();
            
            char[][] mapa = new char[filas][columnas];
            
            for (int i = 0; i < filas; i++)
            {
                // Leemos una línea del mapa
                linea = sc.nextLine();
                for (int j = 0; j < columnas; j++)
                {
                    // Vamos guardando cada letra en su columna
                    mapa[i][j] = linea.charAt(j);
                }
            }
            
            // Procesado del mapa
            
            int valor, max = 0;
                        
            for (int i = 0; i < filas; i++)
            {
                for (int j = 0; j < columnas; j++)
                {
                    if (mapa[i][j] == '#')
                    {
                        valor = calcularArea(mapa, i, j);
                        if (valor > max)
                            max = valor;
                    }
                }
            }

            System.out.println(max);            
        }        
    }
}
