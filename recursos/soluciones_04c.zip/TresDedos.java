// Acepta el Reto 272: Tres dedos en cada mano

import java.util.Scanner;

public class TresDedos
{
	static int base6(int n)
	{
        // Caso base: números menores que 6
		if (n < 6)
			return n;
        // Caso recursivo: vamos acumulando restos al final y dividiendo / 6
		else
		{
			return Integer.parseInt("" + base6(n/6) + (n % 6));
		}
	}
	
    public static void main(String[] args) 
    {
        Scanner sc = new Scanner(System.in);
        int n, casos;
        
        casos = sc.nextInt();
        
        for (int i = 1; i <= casos; i++)
        {
			n = sc.nextInt();
			System.out.println(base6(n));
		}
    }    
}
