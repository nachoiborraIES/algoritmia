// Acepta el Reto 357: la prueba de las cajas y las bolas

import java.util.Scanner;

public class CajasBolas
{	
    static int viajes(int n)
    {
        // Caso base: n = 1 cajas, 1 viaje
        if (n == 1)
            return 1;
        // Caso recursivo: descomponemos el problema en dos de n/2 y sumamos 1 viaje
        else
            return 1 + viajes(n/2);
    }
	
	public static void main(String[] args)
	{
		Scanner sc = new Scanner(System.in);
		int cajas;
		
        // Leemos de la entrada hasta que ya no haya más que leer
		while (sc.hasNext())
		{
			cajas = sc.nextInt();
			System.out.println(viajes(cajas));
		}
	}
}
