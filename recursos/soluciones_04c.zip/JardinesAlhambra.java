// Acepta el Reto 769: Los jardines de la Alhambra

import java.util.Scanner;

public class JardinesAlhambra
{
    static void explorarJardin(char[][] mapa, int fila, int columna)
    {
        if (fila >= 0 && fila < mapa.length && columna >= 0 &&
            columna < mapa[0].length && mapa[fila][columna] != '.')
        {
            // Marcamos la casilla como vacía para no contarla en otro proceso
            mapa[fila][columna] = '.';
            // Exploramos las casillas contiguas
            explorarJardin(mapa, fila-1, columna);
            explorarJardin(mapa, fila+1, columna);
            explorarJardin(mapa, fila, columna-1);
            explorarJardin(mapa, fila, columna+1);
        }
    }    
    
    public static void main(String[] args)
    {
        Scanner sc = new Scanner(System.in);
        int filas, columnas;
        String linea;

        while (sc.hasNext())
        {
            // Construcción del mapa
            
            filas = sc.nextInt();
            columnas = sc.nextInt();
            // Pasamos a la siguiente línea
            sc.nextLine();
            
            char[][] mapa = new char[filas][columnas];
            
            for (int i = 0; i < filas; i++)
            {
                // Leemos una línea del mapa
                linea = sc.nextLine();
                for (int j = 0; j < columnas; j++)
                {
                    // Vamos guardando cada letra en su columna
                    mapa[i][j] = linea.charAt(j);
                }
            }
            
            // Procesado del mapa
            
            int contador = 0;
                        
            for (int i = 0; i < filas; i++)
            {
                for (int j = 0; j < columnas; j++)
                {
                    if (mapa[i][j] == '#')
                    {
                        explorarJardin(mapa, i, j);
                        // Ya hemos encontrado un jardín más
                        contador++;
                    }
                }
            }

            System.out.println(contador);
        }        
    }
}
