// Acepta el Reto 236: Los orígenes del ajedrez

import java.util.Scanner;

public class OrigenesAjedrez
{
    public static void main(String[] args)
    {
        Scanner sc = new Scanner(System.in);
        long granosIniciales, incremento, casillas, granosCasilla, suma;

        do
        {
            granosIniciales = sc.nextInt();
            incremento = sc.nextInt();
            casillas = sc.nextInt();

            if (granosIniciales != 0 || incremento != 0 || casillas != 0)
            {
                // Contamos al inicio los granos de la primera casilla
                suma = granosCasilla = granosIniciales;

                // Recorremos el resto de casillas (desde la segunda)
                for (int i = 2; i <= casillas; i++)
                {
                    // Calculamos los granos que van a esa casilla según los
                    // de la casilla anterior (por el incremento)
                    granosCasilla = granosCasilla * incremento;
                    // Acumulamos los granos de esa casilla en la suma total
                    suma += granosCasilla;
                }

                System.out.println(suma);
            }
        } while (granosIniciales != 0 || incremento != 0 || casillas != 0);
    }
}
