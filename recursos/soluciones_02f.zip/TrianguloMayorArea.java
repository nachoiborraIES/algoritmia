// Acepta el Reto 350: El triángulo de mayor área

import java.util.Scanner;

public class TrianguloMayorArea
{
    public static void main(String[] args)
    {
        Scanner sc = new Scanner(System.in);
        float a, b, area;

        do
        {
            a = sc.nextFloat();
            b = sc.nextFloat();
            if(a != 0 || b != 0)
            {
                area = a * b / 2;
                System.out.printf("%.1f\n", area);
            }
        }
        while(a != 0 || b != 0);
    }
}
