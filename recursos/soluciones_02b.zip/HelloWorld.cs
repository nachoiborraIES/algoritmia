// Kattis: "Hello World!"

using System;

class Ejercicio
{
    static void Main()
    {
        Console.WriteLine("Hello World!");
    }
}
