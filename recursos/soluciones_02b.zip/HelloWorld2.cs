// CodeWars: hello world
// Copiar y pegar este código en el formulario del intento

public static class Kata
{
  public static string greet()
  {
    return "hello world!";
  }
}

